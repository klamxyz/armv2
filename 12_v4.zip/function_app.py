import logging
import azure.functions as func
import os 
# from dotenv import load_dotenv
import time
from datetime import datetime 

# load_dotenv()
interval = os.getenv('INTERVAL', 1)
schedule = f"0 */{interval} * * * *"

app = func.FunctionApp()

@app.timer_trigger(schedule=schedule, arg_name="myTimer", run_on_startup=False,
              use_monitor=True) 
def timer_trigger_12_v44(myTimer: func.TimerRequest) -> None:
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S"
    )
    logging.info(interval)
    myid = datetime.now().strftime("%H:%M:%S")
    logging.info('##########################Python timer trigger function executed.')
    logging.info(myid)

    myparam = True
    start_time = time.time()
    asyncio.run(main(myparam, start_time))

    # time.sleep(300)
    # logging.info(datetime.now().strftime("%d.%m.%Y %H:%M:%S"))
    # for i in range(2500000000):
    #     a = 999*888/90/70
    # logging.info(datetime.now().strftime("%d.%m.%Y %H:%M:%S"))

    # with open(r"myfile.txt", "w") as f: 
    #     print("This is my env: ", os.getenv("AZURE_CLIENT_ID"))
    #     my_env_var = os.getenv("AZURE_CLIENT_ID")
    #     f.write(my_env_var)

    if myTimer.past_due:
        logging.info('The timer is past due!')
        logging.info(myid)

    logging.info('**************************Python timer trigger function executed.')
    logging.info(myid)



import asyncio
import time

async def pull_data():
    # Simulate pulling data (e.g., from an API or database)
    await asyncio.sleep(15)
    data = "blablabla"
    logging.info(f"PULL data: {data}")
    return data

async def send_data(data):
    # Simulate sending data (e.g., to another service)
    await asyncio.sleep(5) 
    logging.info(f"SENT data: {data}")

async def main(myparam, start_time):
    while myparam and (time.time() - start_time) < 75:
        data = await pull_data()
        await send_data(data)
