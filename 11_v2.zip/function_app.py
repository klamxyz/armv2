import logging
import azure.functions as func
import os 
# from dotenv import load_dotenv
import time
from datetime import datetime 

# load_dotenv()
app = func.FunctionApp()

@app.timer_trigger(schedule="0 */2 * * * *", arg_name="myTimer", run_on_startup=False,
              use_monitor=False) 
def timer_trigger_11_v2(myTimer: func.TimerRequest) -> None:
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S"
    )
    myid = datetime.now().strftime("%H:%M:%S")
    logging.info('##########################Python timer trigger function executed.')
    logging.info(myid)

    time.sleep(300)

    # with open(r"myfile.txt", "w") as f: 
    #     print("This is my env: ", os.getenv("AZURE_CLIENT_ID"))
    #     my_env_var = os.getenv("AZURE_CLIENT_ID")
    #     f.write(my_env_var)
    if myTimer.past_due:
        logging.info('The timer is past due!')
        logging.info(myid)

    logging.info('**************************Python timer trigger function executed.')
    logging.info(myid)
